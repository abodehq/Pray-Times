/* generated javascript */
var skin = 'praytimes';
var stylepath = '/w/skins';

/* MediaWiki:Common.js */
/* Any JavaScript here will be loaded for all users on every page load. */

if (mwCustomEditButtons) {

   mwCustomEditButtons[mwCustomEditButtons.length] = {
     "imageFile": "http://praytimes.org/w/skins/common/images/button_code.png",
     "speedTip": "Code",
     "tagOpen": "<code>",
     "tagClose": "</code>",
     "sampleText": "code"};

   mwCustomEditButtons[mwCustomEditButtons.length] = {
     "imageFile": "http://praytimes.org/w/skins/common/images/button_quote.png",
     "speedTip": "Blockquote",
     "tagOpen": "<blockquote>",
     "tagClose": "</blockquote>",
     "sampleText": "Quote"};
}

/* MediaWiki:Praytimes.js */
